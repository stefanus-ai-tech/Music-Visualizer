// ============================================================
// DAISY // RAGE PROTOCOL — CYBERPUNK NEON NIGHTCORE BUILD
// ============================================================

const canvas = document.getElementById('visualizer');
const ctx = canvas.getContext('2d');
const startBtn = document.getElementById('startBtn');
const overlay = document.getElementById('overlay');
const controlsPanel = document.getElementById('controlsPanel');

// Controls
const ctrlRings     = document.getElementById('ctrlRings');
const ctrlReact     = document.getElementById('ctrlReact');
const ctrlNoise     = document.getElementById('ctrlNoise');
const ctrlSpin      = document.getElementById('ctrlSpin');
const ctrlHole      = document.getElementById('ctrlHole');
const ctrlThickness = document.getElementById('ctrlThickness');
const ctrlIntensity = document.getElementById('ctrlIntensity');

// ============================================================
// CYBERPUNK PALETTES
// bg / primary / secondary / accent
// ============================================================
const PALETTES = {
    rage: {
        bg:      '#000000',
        primary: '#ff0090',   // hot pink neon
        fg:      '#ff1a1a',   // blood red
        alt:     '#d4ff00',   // acid yellow
        glow:    'rgba(255,0,144,0.6)'
    },
    nightcore: {
        bg:      '#04000f',
        primary: '#00fff2',   // cyan neon
        fg:      '#b400ff',   // purple neon
        alt:     '#ff0090',   // pink
        glow:    'rgba(0,255,242,0.5)'
    },
    acid: {
        bg:      '#000800',
        primary: '#d4ff00',   // acid green-yellow
        fg:      '#00ff66',   // toxic green
        alt:     '#ff6600',   // orange neon
        glow:    'rgba(212,255,0,0.5)'
    },
    void: {
        bg:      '#000010',
        primary: '#4444ff',   // deep electric blue
        fg:      '#00fff2',   // cyan
        alt:     '#ff00ff',   // magenta
        glow:    'rgba(68,68,255,0.6)'
    }
};

let currentPaletteKey = 'rage';
let pal = PALETTES[currentPaletteKey];

let lastSwapTime = 0;
const SWAP_COOLDOWN = 800;

// Manual palette selection
document.querySelectorAll('.preset-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        document.querySelectorAll('.preset-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        currentPaletteKey = e.target.dataset.preset;
        pal = PALETTES[currentPaletteKey];
    });
});

// ============================================================
// AUDIO
// ============================================================
let audioCtx, analyser, source;
let useRealAudio = false;
const BIN_COUNT = 1024;
const BINS = 64;
const MIN_DB = -90, MAX_DB = -10;
let logIndices = [];
let dataArray;
let time = 0;
let smoothedBins = new Float32Array(BINS).fill(0);

// Beat state
let beatTimer      = 0;
let lastBass       = 0;
let bassEnergy     = 0;
let midEnergy      = 0;
let globalSpin     = 0;
let erraticPhase   = 0;
let erraticPetal   = 0;
let erraticSpike   = 0;
let currentScale   = 1.0;

// Glitch state
let glitchActive   = false;
let glitchTimer    = 0;
let glitchLines    = [];
let chromaShift    = 0;

// ============================================================
// BG PARTICLES — replace flowers with neon shards / sparks
// ============================================================
let bgParticles = [];
for (let i = 0; i < 160; i++) {
    bgParticles.push({
        x:        (Math.random() - 0.5) * 1400,
        y:        (Math.random() - 0.5) * 1400,
        size:     1 + Math.random() * 5,
        angle:    Math.random() * Math.PI * 2,
        speed:    (Math.random() - 0.5) * 0.025,
        parallax: 0.15 + Math.random() * 0.85,
        type:     Math.floor(Math.random() * 3) // 0=cross, 1=diamond, 2=line
    });
}

function resizeCanvas() {
    const phoneMaxWidth = 400;
    let w = Math.min(window.innerWidth, phoneMaxWidth);
    let h = w * (16 / 9);
    if (h > window.innerHeight) {
        h = window.innerHeight;
        w = h * (9 / 16);
    }
    canvas.width  = w;
    canvas.height = h;
}
window.addEventListener('resize', resizeCanvas);

startBtn.addEventListener('click', async () => {
    overlay.style.display = 'none';
    controlsPanel.classList.remove('hidden');
    resizeCanvas();
    dataArray = new Float32Array(BIN_COUNT);

    try {
        const stream = await navigator.mediaDevices.getDisplayMedia({ audio: true, video: true });
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        analyser = audioCtx.createAnalyser();
        analyser.fftSize = BIN_COUNT * 2;
        analyser.smoothingTimeConstant = 0.45;
        source = audioCtx.createMediaStreamSource(stream);
        source.connect(analyser);
        useRealAudio = true;
        setupLogBins();
    } catch (err) {
        useRealAudio = false;
        setupLogBins(true);
    }
    requestAnimationFrame(renderLoop);
});

function setupLogBins(isSimulated = false) {
    logIndices = [];
    const nyquist = (isSimulated ? 44100 : audioCtx.sampleRate) / 2;
    const freqs = Array.from({ length: BIN_COUNT }, (_, i) => i * nyquist / BIN_COUNT);
    const minLog = Math.log10(20), maxLog = Math.log10(16000);
    for (let i = 0; i < BINS; i++) {
        const targetFreq = Math.pow(10, minLog + (i / BINS) * (maxLog - minLog));
        const idx = freqs.findIndex(f => f >= targetFreq);
        logIndices.push(idx === -1 ? freqs.length - 1 : idx);
    }
}

function updateSimulatedFrequencies() {
    for (let i = 0; i < BIN_COUNT; i++) dataArray[i] = -100 + Math.random() * 5;
    const t = time * 0.5;
    const addPeak = (s, e, a) => {
        for (let i = s; i < e; i++) if (-100 + a > dataArray[i]) dataArray[i] = -100 + a;
    };
    if (Math.sin(t * 8) > 0.8) addPeak(1, 5, 80);
    addPeak(10, 15, 60 + Math.sin(t * 2) * 20);
}

function getEnergy(data, from, to) {
    let sum = 0;
    for (let i = from; i < to; i++) sum += Math.max(0, (data[i] - MIN_DB) / (MAX_DB - MIN_DB));
    return sum / Math.max(1, to - from);
}

// ============================================================
// TOGGLE BUTTON
// ============================================================
const toggleUIBtn = document.createElement('button');
toggleUIBtn.id = 'toggleUIBtn';
toggleUIBtn.innerText = '[ HIDE UI ]';
document.body.appendChild(toggleUIBtn);

toggleUIBtn.addEventListener('click', () => {
    controlsPanel.classList.toggle('hidden');
    toggleUIBtn.innerText = controlsPanel.classList.contains('hidden') ? '[ SHOW UI ]' : '[ HIDE UI ]';
});

// ============================================================
// RENDER LOOP
// ============================================================
function renderLoop() {
    requestAnimationFrame(renderLoop);
    time += 0.005;

    if (useRealAudio && analyser) {
        analyser.getFloatFrequencyData(dataArray);
        for (let i = 0; i < dataArray.length; i++) if (!isFinite(dataArray[i])) dataArray[i] = MIN_DB;
    } else {
        updateSimulatedFrequencies();
    }

    const eB = getEnergy(dataArray, 1, Math.floor(BIN_COUNT * 0.05));
    const eM = getEnergy(dataArray, Math.floor(BIN_COUNT * 0.05), Math.floor(BIN_COUNT * 0.3));
    const intensity = ctrlIntensity ? parseFloat(ctrlIntensity.value) : 1.5;

    // BEAT DETECTION
    if (eB - lastBass > 0.02 && eB > 0.05) {
        beatTimer    = 1.0;
        currentScale = 1.12 + eB * 0.35 * intensity;

        // Trigger glitch burst
        glitchActive = true;
        glitchTimer  = 1.0;
        chromaShift  = (Math.random() - 0.5) * 14 * intensity;
        glitchLines  = buildGlitchLines(intensity);

        if (intensity > 0.1) {
            const now = Date.now();
            if (now - lastSwapTime > SWAP_COOLDOWN) {
                lastSwapTime = now;
                const keys = Object.keys(PALETTES).filter(k => k !== currentPaletteKey);
                currentPaletteKey = keys[Math.floor(Math.random() * keys.length)];
                pal = PALETTES[currentPaletteKey];
                document.querySelectorAll('.preset-btn').forEach(b => {
                    b.classList.toggle('active', b.dataset.preset === currentPaletteKey);
                });
            }

            erraticPhase = (Math.random() * Math.PI * 4) * intensity;
            erraticPetal = Math.floor((Math.random() - 0.5) * 16 * intensity);
            erraticSpike = (Math.random() - 0.5) * 0.9 * intensity;
        }
    }
    lastBass = eB;

    beatTimer    *= 0.72;
    glitchTimer  *= 0.78;
    currentScale += (1.0 - currentScale) * 0.25;
    bassEnergy   += (eB - bassEnergy) * 0.4;
    midEnergy    += (eM - midEnergy) * 0.3;
    chromaShift  *= 0.82;

    erraticPhase *= 0.84;
    erraticPetal *= 0.84;
    erraticSpike *= 0.78;

    if (glitchTimer < 0.1) glitchActive = false;

    const spinBase = parseFloat(ctrlSpin.value) * 0.03;
    globalSpin += spinBase + erraticSpike;

    // Smooth bins
    for (let i = 0; i < BINS; i++) {
        const rawDb = dataArray[logIndices[i]] || MIN_DB;
        const norm  = Math.max(0, (rawDb - MIN_DB) / (MAX_DB - MIN_DB));
        const lerp  = beatTimer > 0.5 ? 0.65 : 0.2;
        smoothedBins[i] += (norm - smoothedBins[i]) * lerp;
    }

    const W = canvas.width, H = canvas.height;

    // CLEAR with void bg + subtle trail
    ctx.globalAlpha = 0.88;
    ctx.fillStyle   = pal.bg;
    ctx.fillRect(0, 0, W, H);
    ctx.globalAlpha = 1;

    // Draw subtle grid overlay
    drawGrid(W, H, intensity);

    ctx.save();
    ctx.translate(W / 2, H / 2);

    // Camera shake
    if (intensity > 0 && beatTimer > 0.1) {
        const mag = beatTimer * 28 * intensity;
        ctx.translate((Math.random() - 0.5) * mag, (Math.random() - 0.5) * mag);
    }
    ctx.scale(currentScale, currentScale);

    renderBackground(intensity);
    renderCoreFlower(intensity);

    ctx.restore();

    // CHROMATIC ABERRATION / GLITCH LINES drawn after restore (screen space)
    if (glitchActive) {
        drawGlitchLines(W, H);
        drawChromaticAberration(W, H, intensity);
    }
}

// ============================================================
// GRID OVERLAY
// ============================================================
function drawGrid(W, H, intensity) {
    const gridAlpha = 0.035 + bassEnergy * 0.05;
    ctx.save();
    ctx.strokeStyle = pal.primary;
    ctx.lineWidth   = 0.5;
    ctx.globalAlpha = gridAlpha;
    const spacing   = 40;
    for (let x = 0; x < W; x += spacing) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, H);
        ctx.stroke();
    }
    for (let y = 0; y < H; y += spacing) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(W, y);
        ctx.stroke();
    }
    ctx.restore();
}

// ============================================================
// BACKGROUND PARTICLES (neon shards instead of daisies)
// ============================================================
function renderBackground(intensity) {
    ctx.save();
    ctx.rotate(-globalSpin * 0.7);

    for (let i = 0; i < bgParticles.length; i++) {
        const p = bgParticles[i];
        const dynSpeed = p.speed + p.speed * beatTimer * 8 * intensity;
        p.angle += dynSpeed;

        ctx.save();
        const drift = 550 + midEnergy * (250 + intensity * 180);
        const dx = Math.cos(p.angle) * p.parallax * drift;
        const dy = Math.sin(p.angle) * p.parallax * drift;
        ctx.translate(p.x + dx, p.y + dy);

        if (beatTimer > 0.4 && intensity > 0.8) {
            ctx.translate((Math.random() - 0.5) * 18, (Math.random() - 0.5) * 18);
        }

        const sc = 1.0 + beatTimer * 0.6 * p.parallax * intensity;
        ctx.scale(sc, sc);
        ctx.rotate(p.angle * 1.5);

        const alpha = 0.35 + beatTimer * 0.25;
        ctx.globalAlpha = alpha;
        const col = i % 3 === 0 ? pal.primary : i % 3 === 1 ? pal.fg : pal.alt;
        ctx.strokeStyle = col;
        ctx.fillStyle   = col;
        ctx.shadowColor = col;
        ctx.shadowBlur  = 8 + beatTimer * 12;
        ctx.lineWidth   = p.size * 0.3;

        if (p.type === 0) {
            // cross / plus
            const s = p.size;
            ctx.beginPath();
            ctx.moveTo(-s, 0); ctx.lineTo(s, 0);
            ctx.moveTo(0, -s); ctx.lineTo(0, s);
            ctx.stroke();
        } else if (p.type === 1) {
            // diamond
            const s = p.size * 0.8;
            ctx.beginPath();
            ctx.moveTo(0, -s);
            ctx.lineTo(s, 0);
            ctx.lineTo(0, s);
            ctx.lineTo(-s, 0);
            ctx.closePath();
            ctx.stroke();
        } else {
            // spark line
            const s = p.size * 1.2;
            ctx.beginPath();
            ctx.moveTo(-s, -s * 0.3);
            ctx.lineTo(s, s * 0.3);
            ctx.stroke();
        }
        ctx.restore();
    }
    ctx.restore();
}

// ============================================================
// GLITCH HELPERS
// ============================================================
function buildGlitchLines(intensity) {
    const lines = [];
    const count = Math.floor(3 + Math.random() * 6 * intensity);
    for (let i = 0; i < count; i++) {
        lines.push({
            y:     Math.random(),
            h:     0.005 + Math.random() * 0.03,
            shift: (Math.random() - 0.5) * 30 * intensity,
            alpha: 0.4 + Math.random() * 0.5
        });
    }
    return lines;
}

function drawGlitchLines(W, H) {
    ctx.save();
    for (const l of glitchLines) {
        ctx.globalAlpha = l.alpha * glitchTimer;
        ctx.fillStyle   = pal.primary;
        const y = l.y * H;
        const h = l.h * H;
        // Grab pixel strip and offset it
        try {
            const imgData = ctx.getImageData(0, y, W, h);
            ctx.putImageData(imgData, l.shift, y);
        } catch(e) {}
    }
    ctx.restore();
}

function drawChromaticAberration(W, H, intensity) {
    if (Math.abs(chromaShift) < 0.5) return;
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    ctx.globalAlpha = 0.12 * glitchTimer;

    // Red channel offset
    ctx.fillStyle = `rgba(255,0,80,0.4)`;
    try {
        const img = ctx.getImageData(0, 0, W, H);
        ctx.putImageData(img, chromaShift, 0);
    } catch(e) {}
    ctx.restore();
}

// ============================================================
// CORE FLOWER — now neon wire with hard glitch edges
// ============================================================
function renderCoreFlower(intensity) {
    const baseRingCount = parseInt(ctrlRings.value);
    const reactAmp  = parseFloat(ctrlReact.value);
    const noiseAmp  = parseFloat(ctrlNoise.value) / 25;
    const holeSize  = parseFloat(ctrlHole.value);
    const lineThick = parseFloat(ctrlThickness.value);
    const maxRadius = Math.min(canvas.width, canvas.height) * 0.15;

    ctx.lineJoin  = beatTimer > 0.3 && intensity > 0.5 ? 'miter' : 'round';
    ctx.miterLimit = 6;

    function drawLayer(ringCount, layerRadius, layerAmp, basePetals, phaseMult, isSharp, alpha, audioStart, audioEnd, color, glowColor) {
        const petals = Math.max(1, basePetals + Math.round(erraticPetal));

        for (let i = 0; i < ringCount; i++) {
            const rn      = ringCount > 1 ? i / (ringCount - 1) : 0;
            const rBase   = holeSize * maxRadius + layerRadius * (0.1 + 0.9 * rn);
            const phase   = rn * phaseMult + erraticPhase;

            // Neon glow pass (drawn behind)
            ctx.save();
            ctx.globalAlpha  = alpha * 0.25;
            ctx.strokeStyle  = glowColor;
            ctx.lineWidth    = (lineThick + beatTimer * intensity * 6) * 4;
            ctx.shadowColor  = glowColor;
            ctx.shadowBlur   = 20 + beatTimer * 30;
            ctx.filter       = `blur(${2 + beatTimer * 4}px)`;
            tracePath(rBase, petals, phase, isSharp, audioStart, audioEnd, reactAmp, maxRadius, layerAmp, noiseAmp, intensity);
            ctx.stroke();
            ctx.restore();

            // Hard neon line
            ctx.save();
            ctx.globalAlpha  = alpha;
            ctx.strokeStyle  = color;
            ctx.lineWidth    = lineThick + beatTimer * intensity * 3;
            ctx.shadowColor  = color;
            ctx.shadowBlur   = 10 + beatTimer * 20;
            tracePath(rBase, petals, phase, isSharp, audioStart, audioEnd, reactAmp, maxRadius, layerAmp, noiseAmp, intensity);
            ctx.stroke();

            // On hard beats: fill flash
            if (beatTimer > 0.85 && Math.random() > 0.75 && intensity > 1.0) {
                ctx.globalAlpha = 0.08 * beatTimer;
                ctx.fillStyle   = color;
                ctx.fill();
            }
            ctx.restore();
        }
    }

    function tracePath(rBase, petals, phase, isSharp, audioStart, audioEnd, reactAmp, maxR, layerAmp, noiseAmp, intensity) {
        ctx.beginPath();
        const resolution = 200;
        for (let j = 0; j <= resolution; j++) {
            const t     = (j / resolution) * Math.PI * 2;
            const angle = t + globalSpin;
            const binRatio = Math.sin((j / resolution) * Math.PI);
            const binIdx   = Math.floor(audioStart + (audioEnd - audioStart) * binRatio);
            const audio    = smoothedBins[binIdx] || 0;

            let wave;
            if (isSharp) {
                wave = Math.abs(Math.sin((petals * t + phase) / 2)) * 2 - 1;
            } else {
                wave = Math.cos(petals * t + phase);
            }

            const glitch = intensity > 0.8 ? (Math.random() - 0.5) * beatTimer * intensity * 45 : 0;
            const amp    = layerAmp * noiseAmp + audio * maxR * 0.4 * reactAmp * (1 + intensity);
            const r      = rBase + amp * wave + glitch;

            const x = r * Math.cos(angle);
            const y = r * Math.sin(angle);
            j === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
        }
        ctx.closePath();
    }

    // LAYER 3: OUTER — primary color
    drawLayer(
        Math.floor(baseRingCount * 0.5),
        maxRadius * 0.8, maxRadius * 0.3,
        8, Math.PI, false, 0.9,
        0, 10,
        pal.primary, pal.glow
    );
    // LAYER 2: MID — secondary
    drawLayer(
        Math.floor(baseRingCount * 0.35),
        maxRadius * 0.45, maxRadius * 0.2,
        16, Math.PI * 2, true, 0.85,
        10, 30,
        pal.fg, pal.primary
    );
    // LAYER 1: CORE — accent
    drawLayer(
        Math.floor(baseRingCount * 0.15),
        maxRadius * 0.2, maxRadius * 0.1,
        24, Math.PI * 4, true, 0.95,
        30, 60,
        pal.alt, pal.fg
    );

    // CENTER DOT
    ctx.save();
    const corePulse = 3 + bassEnergy * 12 * parseFloat(ctrlReact.value);
    ctx.beginPath();
    ctx.arc(0, 0, corePulse, 0, Math.PI * 2);
    ctx.fillStyle = pal.primary;
    ctx.shadowColor = pal.primary;
    ctx.shadowBlur  = 20 + beatTimer * 40;
    ctx.globalAlpha = 0.9;
    ctx.fill();
    ctx.restore();
}
